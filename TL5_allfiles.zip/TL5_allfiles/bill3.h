#define BILL3_WIDTH 60 
#define BILL3_HEIGHT 160 
const unsigned short bill3_data[9600]; 
