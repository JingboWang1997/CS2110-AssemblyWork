#define BILL2_WIDTH 60 
#define BILL2_HEIGHT 160 
const unsigned short bill2_data[9600]; 
