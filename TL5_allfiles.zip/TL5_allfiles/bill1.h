#define BILL1_WIDTH 60 
#define BILL1_HEIGHT 160 
const unsigned short bill1_data[9600]; 
