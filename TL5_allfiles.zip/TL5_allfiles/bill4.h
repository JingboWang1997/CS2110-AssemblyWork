#define BILL4_WIDTH 60 
#define BILL4_HEIGHT 160 
const unsigned short bill4_data[9600]; 
