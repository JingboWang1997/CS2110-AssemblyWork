GAME_INTRODUCTION:

The player will control his character, which is a Squirtle that will be born on the top-left corner, to avoid his enemies, which are an alien and a spider. The alien will be born on the top-right corner, and the spider will be born on the bottom-right corner. They will be floating around to catch the Squirtle, and the spider is faster than the alien. There will also be a Blue Gem floating around that the Squirtle can use to evolve into Blastoise, which will have a fasterer speed. However, the evolved Blastoise can only last for 5 time-unit. After this 5 time-unit the Blastoise will transform back into a Squirtle and the Blue Gem starts to float around in the world again. 


TIME_UNIT:

For every 80 pixel units the player travels, the time-unit will increment by 1 to encourage the player to move around more.


OPERATION:

During the game, the up, down, left and right arrow will control the squirtle to go in the corresponding direction. The SELECT (DELETE) key will exit the game back to the title page at any time.


GAME_PROGRESS:

The bottom left cornor will have a score tracker and the bottom right will hve a count down timer only when the Squirtle is evolved into a Blastoise. The count down timer will show how much longer the Blastoise will last until transforming back to a Squirtle.